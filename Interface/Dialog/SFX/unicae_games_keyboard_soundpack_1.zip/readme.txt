This pack includes 10 human typing sounds in different velocities, 
7 generated sounds in different speeds and 32 single keypress sounds. 
Perfect for typewriter effects and in-game dialogue.

Keyboard used: Cherry KC 1000
Recorded with: Shure SM7B
Post-processed with: Izotope Neutron 2

Free to use however you like. 
If you really like the asset though, I'll gladly accept some pocket change through Patreon. :)

https://www.patreon.com/unicaegames